# 07 Kuso AI 視覺化 Brief

## 使用方式

將本文件的 prompt 或 Mermaid 區塊貼給 Kuso AI，用來產生：

- 三角色泳道圖
- 模組依賴圖
- 表格資訊流
- 狀態生命週期圖
- Dashboard / matrix wireframe

若要產出 DFD，請優先使用同資料夾的 `08-closed-loop-dfd.zh-TW.md`。該文件已補上 reject / cancel / request change 的回流閉環，避免視覺化後出現斷點。

## 角色泳道圖 Mermaid

```mermaid
flowchart LR
  subgraph OPM["OPM / DRI Requester"]
    O1["Request Workspace<br/>Add / Reuse popup"]
    O0["Reuse modes<br/>By Item / By Project Package"]
    O2["Edit Demand<br/>Need Date + Line + Carryover + Qty"]
    O3["Submit Package"]
    O4["Action Required<br/>Confirm Need / Cancel"]
    O5["Request Status"]
  end

  subgraph MGR["Manager B"]
    M1["Approval<br/>Pending + History"]
    M2["Demand Analysis<br/>Cost Dashboard"]
    M3["Station Matrix<br/>Drilldown"]
    M4["Progress Tracking"]
  end

  subgraph OM["OM Purchasing"]
    P1["Submission Dashboard"]
    P2["PAS Demand No<br/>Enter PAS Demand No"]
    P3["PAS Quote Result<br/>Quote + Validity + Files"]
    P6["Price Decision<br/>Auto Clear or DRI Chain"]
    P5["Submission Dashboard<br/>Quote Expiry Monitor"]
    P4["Export Package<br/>CFA / ECS"]
  end

  O0 --> O1
  O1 --> O2 --> O3 --> M1
  M1 -->|Approve| M3
  M1 -->|Approve| M4
  O3 --> M2
  M2 -->|Drilldown| M3
  M1 -->|OM Scope| P2
  P2 --> P3 --> P6
  P3 --> P5
  P6 -->|Auto Cleared| P4
  P6 -->|Escalation Required| D1["DRI / Project DRI Review"]
  D1 --> P4
  P3 -->|User confirmation required| O4
  O4 -->|Confirm Need| P4
  O4 -->|Cancel Request| O5
```

## 模組依賴圖 Mermaid

```mermaid
flowchart TD
  A["opm.requestWorkspace"] --> B["opm.demandEditor"]
  R1["opm.addReuseItem.byItem"] --> A
  R2["opm.addReuseItem.byProjectPackage"] --> A
  B --> C["manager.approval"]
  B --> D["manager.demandAnalysis.costDashboard"]
  D --> Q["manager.demandAnalysis.stationMatrix"]
  C --> F["manager.progressTracking"]
  C --> G["om.pasDemandNo"]
  G --> H["om.pasQuoteResult"]
  H --> X["om.quoteExpiryMonitor"]
  H --> P["priceDecision.thresholdCheck"]
  P --> I["opm.actionRequired"]
  P --> R["dri.priceReview"]
  P --> J
  I --> J["om.exportPackage"]
  J --> K["Buyer PR / PO downstream"]
  L["shared.contactDri"] -. read only .- C
  L -. read only .- H
  N["shared.contactPopup"] -. copy contact text .- A
  N -. read only .- C
  N -. read only .- H
  M["shared.itemDetail"] -. read only .- A
  M -. read only .- C
  M -. read only .- H
```

## State Machine Mermaid

```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> Submitted: Submit Package to Manager B
  Submitted --> Approved: Manager Approve
  Submitted --> Rejected: Reject to DRI
  Approved --> WaitingPASDemandNo: OM Scope
  WaitingPASDemandNo --> PASQuoteResult: Move to PAS Quote Result
  PASQuoteResult --> AutoCleared: Quote within threshold
  PASQuoteResult --> PriceEscalationRequired: No history / temporary budget / over threshold
  PASQuoteResult --> WaitingUserAConfirmation: Send to User A when confirmation is required
  AutoCleared --> ReadyForECS
  AutoCleared --> ReadyForCFA
  PriceEscalationRequired --> DRIApproved: DRI approve
  DRIApproved --> ProjectDRIApproved: Project DRI approve
  ProjectDRIApproved --> ReadyForECS
  ProjectDRIApproved --> ReadyForCFA
  WaitingUserAConfirmation --> UserAConfirmed: Confirm Need
  WaitingUserAConfirmation --> CancelledByUserA: Cancel Request
  UserAConfirmed --> ReadyForECS: Expense
  UserAConfirmed --> ReadyForCFA: Capex
  ReadyForCFA --> PackageReady: Export Package
  ReadyForECS --> PackageReady: Export Package
  PackageReady --> ExportedToCFAECS: Mark Exported
  ExportedToCFA --> BuyerReceived
  ExportedToECS --> BuyerReceived
```

## Table Information Flow Prompt

```text
Create a system information-flow diagram for an equipment purchasing handoff system.

Scope only includes three roles:
1. OPM / DRI Requester
2. Manager B
3. OM Purchasing

Show each table as a node. For every table, show:
- Read source
- Write/mutation
- Downstream table/module

Tables:
- OPM Request Workspace Add / Reuse Item
- OPM Draft Items
- OPM Reuse by Item History
- OPM Reuse by Project Package Preview
- OPM Action Required
- OPM Request Status
- Manager Approval Pending
- Manager Approval History
- Manager Demand Analysis Cost Dashboard
- Manager Demand Analysis Station Matrix
- Manager Progress Tracking
- OM Submission Dashboard
- OM PAS Demand No
- OM PAS Quote Result
- OM Quote Expiry Monitor
- OM Export Package
- Shared Contact Popup

Important rules:
- OPM demand row = Need Date + Request Line + Phase + Demand Type + Station or Demand Unit + Qty + optional Carryover.
- Reuse by Item copies source qty and demand breakdown, but retargets copied demand rows to the current OPM target/default phase. Source phase stays as reference only.
- Reuse by Project Package previews/imports a source project/phase/package group into current draft items; users can edit/delete before submit, and imported qty is retargeted to current target/default phase.
- Source Project is only the historical source filter; it is never the new request target.
- OPM submit sends rows to Manager Approval and immediately updates Demand Analysis.
- Manager Approve 後 row 離開 Pending Approval，進 Approval History，並保留在 Progress Tracking / Demand Analysis。
- Manager Demand Analysis 第一層是參考 Excel Dashboard 的 Item x Phase x Unit Cost Dashboard；Station Matrix 是第二層 drilldown。
- PAS Demand No 只記錄 PAS Demand No。
- PAS Quote Result 在同一個 Quote Result card 內記錄 PAS Material No、vendor、price、quote date、quote received date、quote valid until、PDF、Excel。
- Save Quote Info 後會做 price decision：Computer 20%、MFG 10%。門檻內 = Auto Cleared，可進 Export Package；無 history、temporary budget 或超門檻 = DRI -> Project DRI。
- User A 可宣告 line carryover；DRI 負責正式 carryover review；Manager 看 Original/Saving/Effective cost，OM 消費 effective qty。
- 成本計算使用 USD canonical values。VND 顯示、輸入與 export 透過每月 USD-to-VND 匯率換算。
- Quote Expiry 是 Submission Dashboard 內的監控區，顯示 Valid / Expiring Soon / Expired / Missing Valid Until。
- Quote Valid Until is required before Send to User A; show Valid, Expiring Soon, or Expired/Requote Required with a 14-day warning rule.
- User A does not see vendor/supplier info.
- Export Package prepares CFA/ECS and then Buyer handles PO downstream.
- Contact 是右上角 popup 輔助工具，與 row-level Contact DRI 分工。
- Temporary Budget Request input panel 只能出現在 OPM Request Workspace；不可注入 Manager、OM、Contact popup 或 Admin tables。
```

## Dashboard Wireframe Prompt

```text
Design a compact enterprise dashboard wireframe for Manager B Demand Analysis.

Goal:
Manager first sees an Excel Dashboard-style item x phase x unit cost dashboard, then drills into phase x station matrix.

Layout:
Top filter bar:
Project, Phase, View Mode, Clear Filters.

Section 1:
Cost Dashboard.
Columns: Item, Spec, Price, MFG, FATP TE, FATP IQC, FATP PQE, WH, Q-LAB, REL, ENG1, ENG2, ENG3, IT, FAC, Total, Detail.
Each unit cell: Qty or Amount depending on view mode.
Clicking an item/phase/unit cell opens Station Matrix with item + phase + unit filters.

Section 2:
Excel-like station matrix.
Left columns: Project, Item, Spec, Unit Price, Est. Amount.
Phase groups: P1.0 to MP.
Within each phase:
Mainline: CG, BG, FATP, Test, Hybrid, Auto.
Packing: ENG Pack, Zombie, Laser_pico, Rework.
Support: Repair, WH.
Calc: Buffer, Total Demand, Stock, Actual Need.

Style:
High-density enterprise table, not card-heavy.
Use compact font, sticky left columns, horizontal scroll.
```

## Kuso AI 注意事項

- 不要畫成購物車或一般採購網站。
- 視覺要像企業內部 workflow + Excel matrix。
- User A 不看 vendor。
- Manager B 的重點是 approval、progress、quantity reasonableness。
- OM 的重點是 Submission aging、PAS Demand No、PAS Quote Result、quote expiry monitor、Export Package。
