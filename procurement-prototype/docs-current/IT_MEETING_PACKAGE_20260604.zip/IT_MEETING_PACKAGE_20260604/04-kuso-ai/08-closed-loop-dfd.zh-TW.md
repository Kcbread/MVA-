# 08 閉環 DFD：MVA 設備採購系統

## 目的

這份 DFD 用來修正流程圖常見問題：`Reject / Cancel / Request Change` 不能停在原地，必須回到可操作的修改節點，形成閉環。

本文件可直接貼給 Kuso AI / IT，用來產生：

- Context DFD
- Level 1 Process DFD
- Reject / Amendment 閉環圖
- 資料表 / audit trail 流向圖

## DFD 核心規則

- `Reject to DRI` 不代表流程結束，而是回到 User A / OPM 的 `Action Required / Request Workspace` 修改。
- Manager B reject 後，User A 修改需求並重新 submit，回到 Manager B approval。
- OM reject 後，User A / DRI 修正需求，再回到 Manager B approval 或 OM queue，依修改範圍決定。
- DRI / Project DRI price review reject 後，回到 User A / OM correction，不可直接 export。
- User A cancel 才是終止流程，狀態保留在 Request Status / audit trail，不進 active demand / export scope。
- Amendment after bidding 必須保留 previous quote reference，修改後若影響 item/spec/qty，必須回 Manager B re-approval。

## Context DFD

```mermaid
flowchart LR
  UA["External Entity: User A / OPM / DRI Requester"]
  MB["External Entity: Manager B"]
  OM["External Entity: OM Purchasing"]
  DRI["External Entity: DRI / Project DRI"]
  BUYER["External Entity: Buyer Downstream"]
  ADMIN["External Entity: Admin"]

  SYS(("MVA Equipment Purchasing System"))

  UA -->|"Create request, edit demand, confirm/cancel, request change"| SYS
  SYS -->|"Request status, action required, timeline"| UA

  MB -->|"Approve / reject, inspect cost dashboard and station matrix"| SYS
  SYS -->|"Pending approval, approval history, demand analysis, progress"| MB

  OM -->|"PAS Demand No, quote result, quote validity, export package"| SYS
  SYS -->|"Assigned OM work, pending owner, quote expiry, export status"| OM

  DRI -->|"Price escalation review, carryover review"| SYS
  SYS -->|"Pending price review, carryover ledger, review history"| DRI

  SYS -->|"Export package, CFA/ECS handoff, PO downstream reference"| BUYER

  ADMIN -->|"Users, roles, assignment, threshold rules"| SYS
  SYS -->|"Audit events, setup status"| ADMIN
```

## Level 1 Process DFD

```mermaid
flowchart TB
  UA["User A / OPM"]
  MB["Manager B"]
  OM["OM Purchasing"]
  DRI["DRI / Project DRI"]
  BUYER["Buyer Downstream"]
  ADMIN["Admin"]

  P1(("P1 Request Workspace<br/>Add / Reuse / Edit Demand"))
  P2(("P2 Manager Approval"))
  P3(("P3 Demand Analysis<br/>Cost Dashboard + Station Matrix"))
  P4(("P4 OM PAS Demand No"))
  P5(("P5 OM PAS Quote Result<br/>Quote + Validity + Files"))
  P6(("P6 Price Decision"))
  P7(("P7 DRI / Project DRI Review"))
  P8(("P8 Export Package"))
  P9(("P9 Reject / Amendment / Correction Loop"))
  P10(("P10 Admin Setup / Assignment"))

  D1[("D1 requests")]
  D2[("D2 request_demand_lines")]
  D3[("D3 approvals")]
  D4[("D4 pas_quotes")]
  D5[("D5 exports")]
  D6[("D6 audit_events")]
  D7[("D7 carryover_ledger")]
  D8[("D8 users / sessions / om_assignments")]

  UA -->|"new item, reuse item, reuse project package, need date, line, qty, carryover"| P1
  P1 --> D1
  P1 --> D2
  P1 --> D7
  P1 --> D6
  P1 -->|"submit package"| P2

  MB -->|"approve / reject"| P2
  P2 --> D3
  P2 --> D6
  P2 -->|"approved active demand"| P3
  P2 -->|"approved OM scope"| P4
  P2 -->|"reject with reason"| P9

  P3 -->|"read request + demand + carryover + price"| D1
  P3 --> D2
  P3 --> D7
  MB -->|"inspect dashboard / drilldown matrix"| P3

  OM -->|"enter PAS Demand No"| P4
  P4 --> D4
  P4 --> D6
  P4 -->|"move to quote"| P5

  OM -->|"PAS Material No, vendor, unit price, quote date, valid until, PDF, Excel"| P5
  P5 --> D4
  P5 --> D6
  P5 -->|"quote saved"| P6

  P6 -->|"within threshold"| P8
  P6 -->|"no history / temporary budget / over threshold"| P7
  P6 --> D6

  DRI -->|"approve / reject price escalation"| P7
  P7 --> D3
  P7 --> D6
  P7 -->|"approved"| P8
  P7 -->|"rejected with reason"| P9

  OM -->|"select Expense/Capex, export package"| P8
  P8 --> D5
  P8 --> D6
  P8 -->|"CFA/ECS package"| BUYER

  UA -->|"fix request / cancel / confirm revised need"| P9
  OM -->|"reject to DRI / request correction"| P9
  P9 --> D1
  P9 --> D2
  P9 --> D3
  P9 --> D6
  P9 -->|"resubmit if item/spec/qty changed"| P2
  P9 -->|"quote correction only"| P5
  P9 -->|"cancelled"| D1

  ADMIN --> P10
  P10 --> D8
  P10 --> D6
  D8 --> P4
  D8 --> P5
  D8 --> P8
```

## Reject / Change 閉環 DFD

```mermaid
flowchart LR
  UA["User A / OPM"]
  MB["Manager B"]
  OM["OM Purchasing"]
  DRI["DRI / Project DRI"]

  P1(("Request Workspace"))
  P2(("Manager Approval"))
  P3(("OM PAS Quote Result"))
  P4(("DRI / Project DRI Review"))
  P5(("Action Required / Correction"))
  P6(("Export Package"))

  D1[("requests")]
  D2[("request_demand_lines")]
  D3[("approvals")]
  D4[("pas_quotes")]
  D5[("audit_events")]

  UA -->|"submit"| P1
  P1 --> D1
  P1 --> D2
  P1 --> P2

  MB -->|"approve"| P2
  P2 -->|"OM scope"| P3
  MB -->|"reject to DRI + reason"| P2
  P2 -->|"rejected"| P5

  OM -->|"quote result"| P3
  P3 --> D4
  P3 -->|"auto cleared"| P6
  P3 -->|"price escalation required"| P4
  OM -->|"reject to DRI + reason"| P3
  P3 -->|"correction required"| P5

  DRI -->|"approve"| P4
  P4 --> P6
  DRI -->|"reject + reason"| P4
  P4 -->|"correction required"| P5

  UA -->|"edit demand / request change / cancel"| P5
  P5 --> D1
  P5 --> D2
  P5 --> D3
  P5 --> D5
  P5 -->|"item/spec/qty changed: resubmit"| P2
  P5 -->|"quote-only correction"| P3
  P5 -->|"cancel request"| END["Cancelled<br/>not active demand"]

  P6 -->|"exported"| DONE["Buyer downstream"]
```

## Data Store 定義

| Store | Purpose | Reject / Change 行為 |
| --- | --- | --- |
| `requests` | request/package header、status、need date、request type | reject/cancel/change 都更新 status，不刪除原紀錄 |
| `request_demand_lines` | phase、line、station/unit、qty、carryover reference | amendment 建新版本或留下 before/after，不覆蓋原始送出量 |
| `approvals` | Manager / DRI / Project DRI decision | reject 必須有 reason，history 保留 |
| `pas_quotes` | PAS Demand No、PAS Material No、quote、validity、attachments metadata | quote 修改保留 previous quote reference |
| `exports` | Expense/Capex、CFA/ECS package、exported at | rejected/cancelled 不可 export |
| `audit_events` | append-only audit trail | 所有 reject、cancel、resubmit、amendment、export 都必記 |
| `carryover_ledger` | line-to-line carryover events | 不覆蓋 demand；Manager 只看 original/saving/effective |
| `users / sessions / om_assignments` | login、role、OM assignment | OM action must be server-authoritative |

## IT 實作檢查點

- Reject button 必須要求 reason。
- Rejected row 不能進 active export scope。
- Cancelled row 不能進 active demand / cost / export scope。
- Amendment after quote 必須保留 previous quote。
- Item/spec/qty 被改動時必須回 Manager B re-approval。
- Quote-only correction 可以回 OM PAS Quote Result，不必重走 User A 新建。
- DRI / Project DRI reject 不能直接 export。
- 所有閉環事件都要寫 `audit_events`。

## 給 Kuso AI 的 Prompt

```text
Create a closed-loop DFD for an equipment purchasing workflow.

Important: Reject does not end the flow. Every reject must route back to a correction process.

Actors:
- User A / OPM / DRI Requester
- Manager B
- OM Purchasing
- DRI / Project DRI
- Buyer downstream
- Admin

Processes:
P1 Request Workspace
P2 Manager Approval
P3 Demand Analysis
P4 OM PAS Demand No
P5 OM PAS Quote Result
P6 Price Decision
P7 DRI / Project DRI Review
P8 Export Package
P9 Reject / Amendment / Correction Loop
P10 Admin Setup / Assignment

Data stores:
requests, request_demand_lines, approvals, pas_quotes, exports, audit_events, carryover_ledger, users/sessions/om_assignments.

Closed-loop rules:
- Manager reject routes to User A Action Required / Request Workspace.
- OM reject routes to User A / DRI correction.
- DRI or Project DRI reject routes to correction, not export.
- User A cancel is terminal and excluded from active demand/export.
- If item/spec/qty changes after quote, the amendment returns to Manager B re-approval.
- Quote-only correction can return to OM PAS Quote Result.
- Every reject/cancel/amendment/resubmit writes audit_events.
```
