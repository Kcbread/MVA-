# 07 Kuso AI Visualization Brief

## How To Use

Paste the prompts or Mermaid blocks in this file into Kuso AI to generate:

- Three-role swimlane diagram
- Module dependency diagram
- Table information flow
- Status lifecycle diagram
- Dashboard / matrix wireframe

For DFD output, use `08-closed-loop-dfd.en.md` in the same folder first. It explicitly includes reject / cancel / request-change return loops so the generated diagram does not end in dead branches.

## Role Swimlane Mermaid

```mermaid
flowchart LR
  subgraph OPM["OPM / DRI Requester"]
    O1["Request Workspace<br/>Add / Reuse popup"]
    O0["Reuse modes<br/>By Item / By Project Package"]
    O2["Edit Demand<br/>Need Date + Line + Carryover + Qty"]
    O3["Submit Package"]
    O4["Action Required<br/>Confirm Need / Cancel"]
    O5["Request Status"]
  end

  subgraph MGR["Manager B"]
    M1["Approval<br/>Pending + History"]
    M2["Demand Analysis<br/>Cost Dashboard"]
    M3["Station Matrix<br/>Drilldown"]
    M4["Progress Tracking"]
  end

  subgraph OM["OM Purchasing"]
    P1["Submission Dashboard"]
    P2["PAS Demand No<br/>Enter PAS Demand No"]
    P3["PAS Quote Result<br/>Quote + Validity + Files"]
    P6["Price Decision<br/>Auto Clear or DRI Chain"]
    P5["Submission Dashboard<br/>Quote Expiry Monitor"]
    P4["Export Package<br/>CFA / ECS"]
  end

  O0 --> O1
  O1 --> O2 --> O3 --> M1
  M1 -->|Approve| M3
  M1 -->|Approve| M4
  O3 --> M2
  M2 -->|Drilldown| M3
  M1 -->|OM Scope| P2
  P2 --> P3 --> P6
  P3 --> P5
  P6 -->|Auto Cleared| P4
  P6 -->|Escalation Required| D1["DRI / Project DRI Review"]
  D1 --> P4
  P3 -->|User confirmation required| O4
  O4 -->|Confirm Need| P4
  O4 -->|Cancel Request| O5
```

## Module Dependency Mermaid

```mermaid
flowchart TD
  A["opm.requestWorkspace"] --> B["opm.demandEditor"]
  R1["opm.addReuseItem.byItem"] --> A
  R2["opm.addReuseItem.byProjectPackage"] --> A
  B --> C["manager.approval"]
  B --> D["manager.demandAnalysis.costDashboard"]
  D --> Q["manager.demandAnalysis.stationMatrix"]
  C --> F["manager.progressTracking"]
  C --> G["om.pasDemandNo"]
  G --> H["om.pasQuoteResult"]
  H --> X["om.quoteExpiryMonitor"]
  H --> P["priceDecision.thresholdCheck"]
  P --> I["opm.actionRequired"]
  P --> R["dri.priceReview"]
  P --> J
  I --> J["om.exportPackage"]
  J --> K["Buyer PR / PO downstream"]
  L["shared.contactDri"] -. read only .- C
  L -. read only .- H
  N["shared.contactPopup"] -. copy contact text .- A
  N -. read only .- C
  N -. read only .- H
  M["shared.itemDetail"] -. read only .- A
  M -. read only .- C
  M -. read only .- H
```

## State Machine Mermaid

```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> Submitted: Submit Package to Manager B
  Submitted --> Approved: Manager Approve
  Submitted --> Rejected: Reject to DRI
  Approved --> WaitingPASDemandNo: OM Scope
  WaitingPASDemandNo --> PASQuoteResult: Move to PAS Quote Result
  PASQuoteResult --> AutoCleared: Quote within threshold
  PASQuoteResult --> PriceEscalationRequired: No history / temporary budget / over threshold
  PASQuoteResult --> WaitingUserAConfirmation: Send to User A when confirmation is required
  AutoCleared --> ReadyForECS
  AutoCleared --> ReadyForCFA
  PriceEscalationRequired --> DRIApproved: DRI approve
  DRIApproved --> ProjectDRIApproved: Project DRI approve
  ProjectDRIApproved --> ReadyForECS
  ProjectDRIApproved --> ReadyForCFA
  WaitingUserAConfirmation --> UserAConfirmed: Confirm Need
  WaitingUserAConfirmation --> CancelledByUserA: Cancel Request
  UserAConfirmed --> ReadyForECS: Expense
  UserAConfirmed --> ReadyForCFA: Capex
  ReadyForCFA --> PackageReady: Export Package
  ReadyForECS --> PackageReady: Export Package
  PackageReady --> ExportedToCFAECS: Mark Exported
  ExportedToCFA --> BuyerReceived
  ExportedToECS --> BuyerReceived
```

## Table Information Flow Prompt

```text
Create a system information-flow diagram for an equipment purchasing handoff system.

Scope only includes three roles:
1. OPM / DRI Requester
2. Manager B
3. OM Purchasing

Show each table as a node. For every table, show:
- Read source
- Write/mutation
- Downstream table/module

Tables:
- OPM Request Workspace Add / Reuse Item
- OPM Draft Items
- OPM Reuse by Item History
- OPM Reuse by Project Package Preview
- OPM Action Required
- OPM Request Status
- Manager Approval Pending
- Manager Approval History
- Manager Demand Analysis Cost Dashboard
- Manager Demand Analysis Station Matrix
- Manager Progress Tracking
- OM Submission Dashboard
- OM PAS Demand No
- OM PAS Quote Result
- OM Quote Expiry Monitor
- OM Export Package
- Shared Contact Popup

Important rules:
- OPM demand row = Need Date + Request Line + Phase + Demand Type + Station or Demand Unit + Qty + optional Carryover.
- Reuse by Item copies source qty and demand breakdown, but retargets copied demand rows to the current OPM target/default phase. Source phase stays as reference only.
- Reuse by Project Package previews/imports a source project/phase/package group into current draft items; users can edit/delete before submit, and imported qty is retargeted to current target/default phase.
- Source Project is only the historical source filter; it is never the new request target.
- OPM submit sends rows to Manager Approval and immediately updates Demand Analysis.
- Manager Approve moves row out of Pending Approval, into Approval History, and keeps it visible in Progress Tracking and Demand Analysis.
- Manager Demand Analysis first shows an Item x Phase x Unit Cost Dashboard based on the Excel Dashboard sheet; Station Matrix is second-layer drilldown.
- PAS Demand No only records PAS Demand No.
- PAS Quote Result records PAS Material No, vendor, price, quote date, quote received date, quote valid until, PDF, and Excel in one Quote Result card.
- After Save Quote Info, price decision compares quote with history: Computer 20%, MFG 10%. Within threshold = Auto Cleared and can enter Export Package. Missing history, temporary budget, or over threshold = DRI -> Project DRI.
- User A may declare line carryover; DRI owns formal carryover review; Manager sees Original/Saving/Effective cost and OM consumes effective qty.
- Cost calculation uses USD canonical values. VND display/export/input values convert through monthly USD-to-VND exchange rate.
- Quote Expiry is a monitor inside Submission Dashboard for Valid / Expiring Soon / Expired / Missing Valid Until.
- Quote Valid Until is required before Send to User A; show Valid, Expiring Soon, or Expired/Requote Required with a 14-day warning rule.
- User A does not see vendor/supplier info.
- Export Package prepares CFA/ECS and then Buyer handles PO downstream.
- Contact is a topbar popup utility, separate from row-level Contact DRI.
- Temporary Budget Request input panel belongs only inside OPM Request Workspace; it must not be injected into Manager, OM, Contact popup, or Admin tables.
```

## Dashboard Wireframe Prompt

```text
Design a compact enterprise dashboard wireframe for Manager B Demand Analysis.

Goal:
Manager first sees an Excel Dashboard-style item x phase x unit cost dashboard, then drills into phase x station matrix.

Layout:
Top filter bar:
Project, Phase, View Mode, Clear Filters.

Section 1:
Cost Dashboard.
Columns: Item, Spec, Price, MFG, FATP TE, FATP IQC, FATP PQE, WH, Q-LAB, REL, ENG1, ENG2, ENG3, IT, FAC, Total, Detail.
Each unit cell: Qty or Amount depending on view mode.
Clicking an item/phase/unit cell opens Station Matrix with item + phase + unit filters.

Section 2:
Excel-like station matrix.
Left columns: Project, Item, Spec, Unit Price, Est. Amount.
Phase groups: P1.0 to MP.
Within each phase:
Mainline: CG, BG, FATP, Test, Hybrid, Auto.
Packing: ENG Pack, Zombie, Laser_pico, Rework.
Support: Repair, WH.
Calc: Buffer, Total Demand, Stock, Actual Need.

Style:
High-density enterprise table, not card-heavy.
Use compact font, sticky left columns, horizontal scroll.
```

## Kuso AI Notes

- Do not make this look like a shopping cart or generic procurement website.
- The visual style should be internal enterprise workflow + Excel matrix.
- User A does not see vendor.
- Manager B focuses on approval, progress, and quantity reasonableness.
- OM focuses on Submission aging, PAS Demand No, PAS Quote Result, quote expiry monitor, and Export Package.
