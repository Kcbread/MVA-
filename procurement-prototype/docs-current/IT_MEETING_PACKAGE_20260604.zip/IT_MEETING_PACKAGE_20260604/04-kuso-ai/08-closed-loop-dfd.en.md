# 08 Closed-Loop DFD: MVA Equipment Purchasing System

## Purpose

This DFD fixes a common workflow-diagram problem: `Reject / Cancel / Request Change` must not become dead ends. Every rejection must route back to a correction process, and every correction must have a clear downstream path.

This document can be used directly by IT or Kuso AI to generate:

- Context DFD
- Level 1 Process DFD
- Reject / Amendment closed-loop DFD
- Data store and audit trail flow

## DFD Rules

- `Reject to DRI` does not end the workflow. It routes back to User A / OPM `Action Required / Request Workspace`.
- Manager B rejection requires User A to correct and resubmit to Manager B approval.
- OM rejection requires User A / DRI correction, then returns either to Manager B approval or the OM queue depending on the change scope.
- DRI / Project DRI price-review rejection routes to User A / OM correction. It must not go directly to export.
- User A cancellation is terminal. It stays visible in status and audit trail, but is excluded from active demand and export scope.
- Amendment after bidding must retain the previous quote reference. If item/spec/qty changes, the amended request must go back to Manager B re-approval.

## Context DFD

```mermaid
flowchart LR
  UA["External Entity: User A / OPM / DRI Requester"]
  MB["External Entity: Manager B"]
  OM["External Entity: OM Purchasing"]
  DRI["External Entity: DRI / Project DRI"]
  BUYER["External Entity: Buyer Downstream"]
  ADMIN["External Entity: Admin"]

  SYS(("MVA Equipment Purchasing System"))

  UA -->|"Create request, edit demand, confirm/cancel, request change"| SYS
  SYS -->|"Request status, action required, timeline"| UA

  MB -->|"Approve / reject, inspect cost dashboard and station matrix"| SYS
  SYS -->|"Pending approval, approval history, demand analysis, progress"| MB

  OM -->|"PAS Demand No, quote result, quote validity, export package"| SYS
  SYS -->|"Assigned OM work, pending owner, quote expiry, export status"| OM

  DRI -->|"Price escalation review, carryover review"| SYS
  SYS -->|"Pending price review, carryover ledger, review history"| DRI

  SYS -->|"Export package, CFA/ECS handoff, PO downstream reference"| BUYER

  ADMIN -->|"Users, roles, assignment, threshold rules"| SYS
  SYS -->|"Audit events, setup status"| ADMIN
```

## Level 1 Process DFD

```mermaid
flowchart TB
  UA["User A / OPM"]
  MB["Manager B"]
  OM["OM Purchasing"]
  DRI["DRI / Project DRI"]
  BUYER["Buyer Downstream"]
  ADMIN["Admin"]

  P1(("P1 Request Workspace<br/>Add / Reuse / Edit Demand"))
  P2(("P2 Manager Approval"))
  P3(("P3 Demand Analysis<br/>Cost Dashboard + Station Matrix"))
  P4(("P4 OM PAS Demand No"))
  P5(("P5 OM PAS Quote Result<br/>Quote + Validity + Files"))
  P6(("P6 Price Decision"))
  P7(("P7 DRI / Project DRI Review"))
  P8(("P8 Export Package"))
  P9(("P9 Reject / Amendment / Correction Loop"))
  P10(("P10 Admin Setup / Assignment"))

  D1[("D1 requests")]
  D2[("D2 request_demand_lines")]
  D3[("D3 approvals")]
  D4[("D4 pas_quotes")]
  D5[("D5 exports")]
  D6[("D6 audit_events")]
  D7[("D7 carryover_ledger")]
  D8[("D8 users / sessions / om_assignments")]

  UA -->|"new item, reuse item, reuse project package, need date, line, qty, carryover"| P1
  P1 --> D1
  P1 --> D2
  P1 --> D7
  P1 --> D6
  P1 -->|"submit package"| P2

  MB -->|"approve / reject"| P2
  P2 --> D3
  P2 --> D6
  P2 -->|"approved active demand"| P3
  P2 -->|"approved OM scope"| P4
  P2 -->|"reject with reason"| P9

  P3 -->|"read request + demand + carryover + price"| D1
  P3 --> D2
  P3 --> D7
  MB -->|"inspect dashboard / drilldown matrix"| P3

  OM -->|"enter PAS Demand No"| P4
  P4 --> D4
  P4 --> D6
  P4 -->|"move to quote"| P5

  OM -->|"PAS Material No, vendor, unit price, quote date, valid until, PDF, Excel"| P5
  P5 --> D4
  P5 --> D6
  P5 -->|"quote saved"| P6

  P6 -->|"within threshold"| P8
  P6 -->|"no history / temporary budget / over threshold"| P7
  P6 --> D6

  DRI -->|"approve / reject price escalation"| P7
  P7 --> D3
  P7 --> D6
  P7 -->|"approved"| P8
  P7 -->|"rejected with reason"| P9

  OM -->|"select Expense/Capex, export package"| P8
  P8 --> D5
  P8 --> D6
  P8 -->|"CFA/ECS package"| BUYER

  UA -->|"fix request / cancel / confirm revised need"| P9
  OM -->|"reject to DRI / request correction"| P9
  P9 --> D1
  P9 --> D2
  P9 --> D3
  P9 --> D6
  P9 -->|"resubmit if item/spec/qty changed"| P2
  P9 -->|"quote correction only"| P5
  P9 -->|"cancelled"| D1

  ADMIN --> P10
  P10 --> D8
  P10 --> D6
  D8 --> P4
  D8 --> P5
  D8 --> P8
```

## Reject / Change Closed-Loop DFD

```mermaid
flowchart LR
  UA["User A / OPM"]
  MB["Manager B"]
  OM["OM Purchasing"]
  DRI["DRI / Project DRI"]

  P1(("Request Workspace"))
  P2(("Manager Approval"))
  P3(("OM PAS Quote Result"))
  P4(("DRI / Project DRI Review"))
  P5(("Action Required / Correction"))
  P6(("Export Package"))

  D1[("requests")]
  D2[("request_demand_lines")]
  D3[("approvals")]
  D4[("pas_quotes")]
  D5[("audit_events")]

  UA -->|"submit"| P1
  P1 --> D1
  P1 --> D2
  P1 --> P2

  MB -->|"approve"| P2
  P2 -->|"OM scope"| P3
  MB -->|"reject to DRI + reason"| P2
  P2 -->|"rejected"| P5

  OM -->|"quote result"| P3
  P3 --> D4
  P3 -->|"auto cleared"| P6
  P3 -->|"price escalation required"| P4
  OM -->|"reject to DRI + reason"| P3
  P3 -->|"correction required"| P5

  DRI -->|"approve"| P4
  P4 --> P6
  DRI -->|"reject + reason"| P4
  P4 -->|"correction required"| P5

  UA -->|"edit demand / request change / cancel"| P5
  P5 --> D1
  P5 --> D2
  P5 --> D3
  P5 --> D5
  P5 -->|"item/spec/qty changed: resubmit"| P2
  P5 -->|"quote-only correction"| P3
  P5 -->|"cancel request"| END["Cancelled<br/>not active demand"]

  P6 -->|"exported"| DONE["Buyer downstream"]
```

## Data Store Definitions

| Store | Purpose | Reject / Change Behavior |
| --- | --- | --- |
| `requests` | Request/package header, status, need date, request type | Reject/cancel/change updates status but does not delete records |
| `request_demand_lines` | Phase, line, station/unit, qty, carryover reference | Amendment creates versioned before/after records or preserves original submitted qty |
| `approvals` | Manager / DRI / Project DRI decisions | Reject requires a reason and remains in history |
| `pas_quotes` | PAS Demand No, PAS Material No, quote, validity, attachment metadata | Quote amendment keeps previous quote reference |
| `exports` | Expense/Capex, CFA/ECS package, exported at | Rejected/cancelled rows cannot export |
| `audit_events` | Append-only audit trail | All reject, cancel, resubmit, amendment, export events are recorded |
| `carryover_ledger` | Line-to-line carryover events | Does not overwrite demand; Manager sees original/saving/effective |
| `users / sessions / om_assignments` | Login, role, OM assignment | OM actions must be server-authoritative |

## IT Implementation Checks

- Reject buttons must require a reason.
- Rejected rows must not enter active export scope.
- Cancelled rows must not enter active demand/cost/export scope.
- Amendment after quote must preserve the previous quote.
- If item/spec/qty changes, the row must return to Manager B re-approval.
- Quote-only correction can return to OM PAS Quote Result without re-creating the request.
- DRI / Project DRI rejection must not route directly to export.
- All closed-loop events must write to `audit_events`.

## Prompt for Kuso AI

```text
Create a closed-loop DFD for an equipment purchasing workflow.

Important: Reject does not end the flow. Every reject must route back to a correction process.

Actors:
- User A / OPM / DRI Requester
- Manager B
- OM Purchasing
- DRI / Project DRI
- Buyer downstream
- Admin

Processes:
P1 Request Workspace
P2 Manager Approval
P3 Demand Analysis
P4 OM PAS Demand No
P5 OM PAS Quote Result
P6 Price Decision
P7 DRI / Project DRI Review
P8 Export Package
P9 Reject / Amendment / Correction Loop
P10 Admin Setup / Assignment

Data stores:
requests, request_demand_lines, approvals, pas_quotes, exports, audit_events, carryover_ledger, users/sessions/om_assignments.

Closed-loop rules:
- Manager reject routes to User A Action Required / Request Workspace.
- OM reject routes to User A / DRI correction.
- DRI or Project DRI reject routes to correction, not export.
- User A cancel is terminal and excluded from active demand/export.
- If item/spec/qty changes after quote, the amendment returns to Manager B re-approval.
- Quote-only correction can return to OM PAS Quote Result.
- Every reject/cancel/amendment/resubmit writes audit_events.
```
