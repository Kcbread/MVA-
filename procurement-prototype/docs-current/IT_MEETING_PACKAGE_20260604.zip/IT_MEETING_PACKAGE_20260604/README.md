# IT Meeting Package - MVA Procurement Prototype

## Purpose

This package is prepared for the IT meeting and Kuso AI visualization work.

Use it for:

- Live product demo.
- Cross-role workflow explanation.
- Table information flow review.
- Kuso AI flowchart / swimlane / module diagram generation.
- MySQL POC / OM internal test alignment.

## Recommended Reading Order

1. `01-demo/demo-checklist.md`
   - Use this during the live screen demo.
2. `02-flow-sop-zh-TW/05-cross-role-flow.zh-TW.md`
   - Main cross-role workflow in Traditional Chinese.
3. `02-flow-sop-zh-TW/06-table-information-flow.zh-TW.md`
   - Table read/write/downstream flow in Traditional Chinese.
4. `03-flow-sop-en/05-cross-role-flow.en.md`
   - English cross-role workflow.
5. `03-flow-sop-en/06-table-information-flow.en.md`
   - English table information flow.
6. `04-kuso-ai/08-closed-loop-dfd.zh-TW.md`
   - Closed-loop DFD source. Use this when reject / cancel / request-change loops must be explicit.
7. `04-kuso-ai/08-closed-loop-dfd.en.md`
   - English closed-loop DFD source.
8. `04-kuso-ai/07-kuso-ai-visualization-brief.zh-TW.md`
   - Prompt and Mermaid material for Kuso AI.
9. `05-mysql-uat/mac-mini-mysql-poc-setup-guide.zh-TW.md`
   - Mac mini / internal LAN MySQL POC setup.

## Current PM Position

- The prototype is ready for screen demo.
- MySQL Phase 1 is scoped to server session, server-authoritative role, OM assignment, and audit trail.
- Workflow data is not fully migrated to MySQL yet.
- Frontend must not connect to MySQL directly.
- Architecture principle: Browser -> Node API -> MySQL.
- OM internal test deployment target: Mac mini / internal LAN test host.

## Scope For IT Discussion

- Confirm MySQL POC host and account provisioning.
- Confirm UAT user accounts and role ownership.
- Confirm Phase 1 API scope before moving full workflow data.
- Confirm attachment v1 stores filename/metadata only.
- Confirm Kuso AI diagram outputs: swimlane, module map, table information flow, status lifecycle.
- Confirm closed-loop rejection behavior: Manager reject, OM reject, DRI reject, User A cancel, and amendment after quote.
